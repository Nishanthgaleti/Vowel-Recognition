// assignment2a.cpp : Defines the entry point for the console application.

// assignment3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"			// conatins <stdio.h>
#include <string.h>			// for memset() - used in clearing a buffer
#include <math.h>			// for abs()
#include <conio.h>			// for getch()
#include <stdlib.h>


#define sample_size 100		// a frame of 100 samples
#define eval_samples 320    // a frame under evaluation (20 millisecs * 16000 samples/sec = 320 samples)
#define past_samples 12		// number of past samples to work with in Linear Predictive Coding (LPC)
#define norm_value 5000		// normalization factor
#define pathsize 4096		// buffer size for path
#define sample_rate 16000	// sample rate used in CoolEdit
// #define path "F:\\IITG\\sem 1\\Speech processing\\CoolEdit recordings\\Day 8\\assigment2a\\assignment2a\\"		//change it to your extracted folder
#define msgsize 1024		// buffer size for console message
#define header "196101005_" // starting names of files
#define considered_steady_frames 5 //no. of frames taken out from steady part
#define training_utterances 5		// no. of training utterances of each vowel
#define testing_utterances 10	// no. of testing utterances of each vowel
#define no_of_vowels 5			// no. of vowels in English
#define force_stop_training 0	// control variable used to avoid training if required

char vowels[5][2] = {"a", "e", "i", "o", "u"};

void dc_remover(char srcfile[], char destfile[])
{

	long double sample_count, mean, curr_value, new_value, energy_sum;
	char srcpath[pathsize], destpath[pathsize];


	FILE *reader,*remover;
	reader = fopen(srcfile,"r");
	remover = fopen(destfile,"w");
	if(reader==NULL)
		printf("dc: Can't read file!\n");
	else
	{
		energy_sum = 0;
		sample_count = 0;
		while(fscanf(reader,"%Lf\n",&curr_value)!=EOF)
		{
			sample_count++;
			energy_sum += curr_value;
		}

		mean = energy_sum/sample_count;

		fseek(reader,0L,SEEK_SET);

		while(fscanf(reader,"%Lf\n",&curr_value)!=EOF)
		{
			new_value = curr_value - mean;
			fprintf(remover, "%Lf\n",new_value);
		}

	}
	
	fclose(reader);
	fclose(remover);
}

long double* normalize_waveform(char in_filepath[])
{
	long double curr_value, sample_number, max_sample, max_energy;
	static long double result[2];
	FILE *reader, *normalizer;

	reader = fopen(in_filepath,"r");
	normalizer = fopen("normalized.txt","w+");  

	if(reader==NULL)
		printf("normalize: Cannot open file");
	else
	{
		// finding out the maximum energy value
		fscanf(reader,"%Lf\n",&curr_value);                     // %Lf access specifier for long double
		max_energy = curr_value;
		sample_number = 1;
		// to find max energy, we first need to store the first energy in max_energy. So all the markers start numbering from 1, not 0
		max_sample = sample_number;

		while(fscanf(reader,"%Lf\n",&curr_value) != EOF)
		{
			sample_number++;	
			if(abs(curr_value)>abs(max_energy))
			{
				max_energy = curr_value;   
				max_sample = sample_number;
			}                        
		}


		// normalizing energy values
		fseek(reader, 0, SEEK_SET);
		long double normalized, find_peak;
				
		find_peak = 0;
		while(fscanf(reader,"%Lf\n",&curr_value) != EOF)
		{
			find_peak++;
			normalized = (curr_value/max_energy)*norm_value;
			fprintf(normalizer,"%Lf\n",normalized);
			if(find_peak==max_sample)
				result[0] = normalized;			
		}

		result[1] = max_sample;
		fclose(reader);
		fclose(normalizer);
		return result;
	}

	fclose(reader);
	fclose(normalizer);
}


void extract_frame(int i, long double limit, long double s[])
{
	FILE *reader;
	//reader reads the speech waveform; and writer writes the sample numbers where we possibly put the markers
	
	reader = fopen("normalized.txt","r");

	if(reader==NULL)
		printf("markers: Can't open file!");
	else
	{
		long double start_marker, end_marker, curr_value, sample_count;


		//use this when you pick up 320 samples from middle region of speech
		
		sample_count = 1;
		start_marker = limit+(eval_samples*i);
		end_marker = start_marker+(eval_samples-1);
		// selected range for 320 samples

		while(sample_count<start_marker)
		{
			//going till start marker
			fscanf(reader,"%Lf\n",&curr_value);
			sample_count++;
		}

		int pos = 0;
		while(sample_count<=end_marker)
		{
			//extracting our samples
			fscanf(reader,"%Lf\n",&curr_value);
			s[pos] = curr_value;
			pos++;
			sample_count++;
		}
		


	}

	fclose(reader);
}



void compute_r_i(long double s[], long double r[])
{
	FILE  *writer;
	writer = fopen( "r_i.txt","w");

	int m, k;
	long double r_i;
	for(k=0; k<past_samples+1; k++)		//since we need values from r[0] to r[past_samples]
	{
		r_i = 0;
		for(m=0; m<=(eval_samples-1-k); m++)
			r_i += s[m]*s[m+k];

		r[k] = r_i;
		fprintf(writer, "%Lf\n", r[k]);
	}

	fclose(writer);
}


int compute_coefficients_Durbin(long double r[], long double a[]) 
{
	FILE  *writer;

	long double e[past_samples+1] = {0};
	long double k[past_samples+1] = {0};
	long double b[past_samples+1][past_samples+1];
	int i, j;

	writer = fopen("coefficients.txt","w");

	e[0] = r[0];
	if(e[0]==0)
	{
		fclose(writer);
		return 0;
	}

	long double sum;
	for(i=1; i<=past_samples; i++)
	{
		sum = 0;
		for(j=1; j<=(i-1); j++)
			sum += b[i-1][j]*r[i-j];

		k[i] = (r[i]-sum)/e[i-1];
		
		b[i][i] = k[i];

		for(j=1; j<=i-1; j++)
			b[i][j] = b[i-1][j] - (k[i]*b[i-1][i-j]);

		e[i] = (1 - k[i]*k[i]) * e[i-1];
	}

	for(i=1; i<=past_samples; i++)
	{
		a[i] = b[past_samples][i];
		fprintf(writer, "%Lf\n", a[i]);
	}

	fclose(writer);
	return 1;
}


void compute_cepstral_coefficients(long double a[], long double c[])
{
	FILE *reader, *writer;

	writer = fopen("cepstral_coefficients.txt","w");
	

	int i=1;			
	long double curr_value;

	// not needed if we do not use raised sine window

	reader = fopen("rsw_values.txt","r");
	long double rsw[past_samples+1] = {0};

	while(fscanf(reader, "%Lf\n", &curr_value)!= EOF)
	{
		rsw[i] = curr_value;				//rsw values stored from index 1
		i++;
	}

	int k, q;
	long double sum, num, l_i, l_k;
	q = past_samples;
	for(i=1; i<=q; i++)
	{
		sum = 0;
		l_i = (long double)i;
		for(k=1; k<=(i-1); k++)
			{
				l_k = (long double)k;
				num = (l_k/l_i)*c[k]*a[i-k];
				//printf("\nnum=%Lf",num);
				sum += num;
			}

		//printf("\nsum=%Lf",sum);
		c[i] = a[i]+sum;		
	}


	// use this when you want to apply raised sine window on c[i] values
	
	for(i=1; i<=q; i++)
	{
		c[i] = c[i]*rsw[i];			//use this only if you want to use RS window, hopefully will give correct results now!
		fprintf(writer, "%Lf\n", c[i]);
	}
	
	fclose(reader);					//use this only if you want to use RS window, hopefully will give correct results now!
	fclose(writer);
}


void myflush ( FILE *in )
{
/* This implementation is actually two functions. The problem is that if the stream is not empty, calling mypause will fail to work
   because getchar will read a character that's already present instead of block. However, if the stream is empty, calling myflush first
   will cause two blocks: first for the flush, and then for the pause. So the two are used alone or together at the appropriate time to 
   work for most cases: */
  int ch;
  do
    ch = fgetc ( in ); 
  while ( ch != EOF && ch != '\n' ); 
  clearerr ( in );
}

void mypause (char msg[]) 
{ 
  strcat(msg,"\nPress [ENTER] to continue...");
  printf ("%s",msg);
  fflush ( stdout );
  getchar();
} 


void get_cepstral(int training, int index, long double c_vowel[][past_samples], char vowel[], char filenum[], long double s[], long double r[], long double a[], long double c[])
{
	char display[msgsize], in_filepath[pathsize];
	

	int success, framenum, count_ci;

	if(vowel[0]!='z')
	{
		//creating reference files for vowel recognition, using file indices only from 1 to 5
		//filename creation
		_snprintf(in_filepath, sizeof(in_filepath), "%s%s%s%s%s", header, vowel, "_", filenum, ".txt");

		//handle dc shift
		//printf("\nStep 1: Removing DC component......");
		dc_remover(in_filepath,"dc_removed.txt");

		/*
		memset(display,0,msgsize);
		strcpy(display, "\n\nDC component removed! Get individual words into separate text files.");
		mypause(display);

		*/
	}

	else
	{
		dc_remover("input_file.txt","dc_removed.txt");
	}
	//normalize data
	//printf("\nStep 2: Normalizing text data......");

	long double *max_ptr;
	long double limit;

	max_ptr = normalize_waveform("dc_removed.txt");    // return max
	limit = max_ptr[1] - (eval_samples*considered_steady_frames)/2;

	/*
	memset(display,0,msgsize);
	strcpy(display, "\n\nData normalized !");	
	mypause(display);
	*/
	// taking 320 samples from the middle region of speech; later modified also for first 320 samples
		//printf("%Lf %Lf",max_ptr[0],max_ptr[1]);
	//printf("\nStep 3: Extracting the frame of 320 samples");

	for(framenum=0; framenum < considered_steady_frames; framenum++)
	{
		//resetting all buffers
		memset(s, 0, sizeof(s));
		memset(r, 0, sizeof(r));
		memset(a, 0, sizeof(a));
		memset(c, 0, sizeof(c));
		
		extract_frame(framenum, limit, s);

		/*
		memset(display,0,msgsize);
		strcpy(display, "\n\nExtracted the required frame !");	
		mypause(display);
		*/



		//getting the R_i values
		//printf("\nStep 4: Computing the R_i values......");
		compute_r_i(s, r);

		/*
		memset(display,0,msgsize);
		strcpy(display, "\n\nR_i values calculated and written to a file!");	
		mypause(display);
		*/
		//Using Durbin's algorithm to approximate a_i values 

		//printf("\nStep 5: Computing the A_i values (signal coefficients)......");
		success = compute_coefficients_Durbin(r, a);


		if(success)
		{	/*
			memset(display,0,msgsize);
			strcpy(display, "\n\nA_i values calculated and written to a file!");	
			mypause(display);
			*/
		}
		else
			printf("\n\nR[0] must have been 0, so no energy in the signal !");



		//we won't get our representation using a_i values only; need to calculate c_i
		//printf("\nStep 6: Computing the C_i values (cepstral coefficients)......");
		compute_cepstral_coefficients(a, c);

		/*
		memset(display,0,msgsize);
		strcpy(display, "\n\nC_i values calculated and written to a file!");	
		mypause(display);
		*/

		if(training)
		{
			//collecting c[i] values for each frame of this utterence
			for(count_ci = 0; count_ci < past_samples; count_ci++)
				c_vowel[framenum + index][count_ci] = c[count_ci+1]; //since c[i] is stored from index 1
		}

		else
		{
			FILE *writer;
			writer = fopen("test_vowel_cepstrals.txt", "w");

			for(count_ci = 0; count_ci < past_samples; count_ci++)
			{
				c_vowel[framenum][count_ci] = c[count_ci+1]; //since c[i] is stored from index 1

				if(count_ci < past_samples - 1)
					fprintf(writer, "%Lf\t", c[count_ci+1]);
				else
					fprintf(writer, "%Lf\n", c[count_ci+1]);

			}	

			fclose(writer);
		}
	}

}


void calculate_avg_ci_for_vowel(long double c_vowel[][past_samples], char vowel[])
{
	int i,j,k, framenum;
	long double avg, sum;
//	long double final_cepstrals[training_utterances][past_samples];

	char out_filepath[pathsize];
	_snprintf(out_filepath, sizeof(out_filepath), "%s%s%s", header, vowel, "_reference.txt");

	FILE *writer;
	writer = fopen(out_filepath, "w");

/*
	we have c_vowel matrix of 25 rows and 12 cols of each vowel. Like for "a", we have stored first five rows as frames from a1, next 5
	rows as frames from a2 and so on . (here a_i means ith utterance of "a"). So, now, we pickup the c_i values from frame 1 of each of 
	a1, a2, a3, a4, a5 (stored in indices [0,5,10,15,20]), then:
		- calculate mean of c[0] of those 5, and store it in file position new_c[0][0]. 
		- calculate mean of c[n] of those 5, and store it in file position new_c[0][n].

	Then we takeup the c_i values from frame 2 of each utterance (stored in indices [1,6,11,16,21]) and then continue the same way - 
	the values are put in file position c[1][0]....c[1][11].

	and so on we get a resultant marix of dimensions 5X12

*/
	for(i = 0; i < considered_steady_frames; i++) // for determining frame base positions in c_vowel
	{
		for(j = 0; j < past_samples; j++)		// for iterating through columns of the matrix c_vowel
		{
			sum = 0;

			for(k = 0; k < training_utterances; k++)		// for determining exact frame position using base position (found from i)
			{
				sum += c_vowel[i + (k*training_utterances)][j];	
			}

			avg = sum/training_utterances;		// value of new_c_ij

			if(j < past_samples - 1)
				fprintf(writer, "%Lf\t", avg);			//keep printing 12 Ci values

			else
				fprintf(writer, "%Lf\n", avg);			//print next line on new line
		}
	}

	fclose(writer);
}


int tokura_analysis(long double c_vowel_testing[][past_samples])
{
	FILE *tokura_reader, *reference_reader, *distance_writer;
	int i, j, ci_counter, vowel_index;
	char in_filepath[pathsize];
	long double tokura_distances[considered_steady_frames];
	long double product, curr_value, ci_reference, total_distance, frame_distance, min_distance;
	long double tokura_weights[past_samples];
	long double total_distances[no_of_vowels];

	tokura_reader = fopen("tokura_wts.txt", "r");
	distance_writer = fopen("total_tokura_distances.txt", "w");

	i = 0;
	while(fscanf(tokura_reader, "%Lf\n", &curr_value) != EOF)
	{
		tokura_weights[i] = curr_value;
		i++;
	}


	for(i = 0; i<no_of_vowels; i++)
	{
		memset(tokura_distances, 0, considered_steady_frames);
		memset(in_filepath, 0, pathsize);

		_snprintf(in_filepath, sizeof(in_filepath), "%s%s%s", header, vowels[i], "_reference.txt");
		reference_reader = fopen(in_filepath, "r");

		total_distance = 0;
		for(j = 0; j<considered_steady_frames; j++)
		{
			ci_counter = 0;
			frame_distance = 0;

			while(fscanf(reference_reader, "%Lf\t", &ci_reference) != EOF)
			{
				product = c_vowel_testing[j][ci_counter] - ci_reference;
				frame_distance += tokura_weights[ci_counter] * product * product;
				ci_counter++;
				if(ci_counter==past_samples)
					break;
			}

			tokura_distances[j] = frame_distance;
			total_distance += tokura_distances[j];
		}

		total_distances[i] = total_distance;
		fprintf(distance_writer, "%Lf\n", total_distances[i]);
		fclose(reference_reader);
	}

	vowel_index = 0;
	min_distance = total_distances[vowel_index];
	
	for(i = 1; i<no_of_vowels; i++)
	{
		if(total_distances[i]<min_distance)
			{
				vowel_index = i;
				min_distance = total_distances[i];
			}
	}

	fclose(tokura_reader);
	fclose(distance_writer);

	return vowel_index;
}


int _tmain(int argc, _TCHAR* argv[])
{
				
	char display[msgsize];
	char in_filepath[pathsize];
	char num[3], ch_time[10];
	
	int timeslice, option, vowel_match, overall_match, vowel_num, utterance_num, index, training, recognized_vowel_index;

	
	long double vowel_accuracy, overall_accuracy;

	long double s[eval_samples];	// 320 samples evaluate as of now
	long double r[past_samples+1];	// p+1 values of R_i
	long double a[past_samples+1];	// p values of A_i stored from index 1
	long double c[past_samples+1];	// p values of C_i stored from index 1
	long double c_vowel_training[considered_steady_frames * training_utterances][past_samples]; //stored from index 0
	long double c_vowel_testing[considered_steady_frames][past_samples];

	//training 
	// generating reference file for each vowel
		
	if(force_stop_training==0)
	{
		training = 1;		// the variable only has boolean use here 

		for(vowel_num=0; vowel_num < no_of_vowels; vowel_num++)
		{
			
			//resetting 2D buffer
			memset(c_vowel_training, 0, sizeof(c_vowel_training[0][0]) * past_samples * (considered_steady_frames*training_utterances));	
			
			for(utterance_num=1;utterance_num<=training_utterances;utterance_num++)
			{
				index = (utterance_num - 1) * training_utterances;

				memset(num,0,3);

				sprintf(num,"%d",utterance_num);

				get_cepstral(training, index, c_vowel_training, vowels[vowel_num], num, s, r, a, c);


			}

			calculate_avg_ci_for_vowel(c_vowel_training, vowels[vowel_num]);

			printf("\nReference file determined for %s !\n\n", vowels[vowel_num]);	

		}
	}

		
				
	do
	{
		
		printf("\nModule Menu: ");
		printf("\n1. Recognize on own vowel file \n2. Recognize on live recording \n3. Exit\n\n");
		scanf("%d",&option);

		switch(option)
		{
			case 1: 
					//testing on pre-recorded input

					training = 0;
					overall_match = 0;

					for(vowel_num=0; vowel_num < no_of_vowels; vowel_num++)
					{
						index = vowel_num * no_of_vowels;
						vowel_match = 0;

						printf("\n\nStarting recognition system for vowel %s\n\n", vowels[vowel_num]);

						for(utterance_num=training_utterances+1; utterance_num <= testing_utterances + training_utterances; utterance_num++)		//since testing file numbers from 6 to 15
						{
							//resetting 2D buffer
							memset(c_vowel_testing, 0, sizeof(c_vowel_testing[0][0]) * past_samples * considered_steady_frames);	

							memset(num,0,3);

							sprintf(num,"%d",utterance_num);

							get_cepstral(training, index, c_vowel_testing, vowels[vowel_num], num, s, r, a, c);
							// the argument index has no use during testing; kept only for format

							recognized_vowel_index = tokura_analysis(c_vowel_testing);

							printf("\nActual vowel: %s\t Recognized vowel: %s", vowels[vowel_num], vowels[recognized_vowel_index]);	

							if(vowel_num==recognized_vowel_index)
							{
								vowel_match++;
								overall_match++;
							}

						}

						vowel_accuracy = (vowel_match/testing_utterances) * 100;
						printf("\nAccuracy in recognizing %s : %Lf", vowels[vowel_num], vowel_accuracy);
						
					}
		
					overall_accuracy = (overall_match/(testing_utterances*5)) * 100;
					printf("\n\n Overall accuracy of the system : %Lf\n", overall_accuracy);
					break;

			case 2: 
					//testing on live recording
					training = 0;
					overall_match = 0;

					printf("\nEnter recording time (in integral seconds): ");
					scanf("%d",&timeslice);
					
					//resetting buffers
					memset(in_filepath,0,pathsize);
					memset(ch_time,0,sizeof(ch_time));
					memset(num,0,3);
					sprintf(ch_time,"%d",timeslice);
					sprintf(num,"%d",99);

					_snprintf(in_filepath, sizeof(in_filepath), "%s %s %s %s","Recording_Module.exe", ch_time, 
							"input_file.wav","input_file.txt");
					//Ex. - ("Recording_Module.exe 3 input_file.wav input_file.txt");

					system(in_filepath);
			
					//resetting 2D buffer
					memset(c_vowel_testing, 0, sizeof(c_vowel_testing[0][0]) * past_samples * considered_steady_frames);	
					memset(s, 0, sizeof(s));
					memset(r, 0, sizeof(r));
					memset(a, 0, sizeof(a));
					memset(c, 0, sizeof(c));	

					index = 999;		//useless variable here
					get_cepstral(training, index, c_vowel_testing, "z", num, s, r, a, c);	//'z''here just means we aren't training
					recognized_vowel_index = tokura_analysis(c_vowel_testing);

					printf("\n\nRecognized vowel : %s",vowels[recognized_vowel_index]);
	
					break;

			case 3: printf("\nExiting module ...");
					break;

			default:printf("\nInvalid input! Please select a valid option again...");

		}
		
	} while(option !=3);


	getch();
	return 0;
}



